/**
 * Точка входа игры + магазин, достижения, мини-игра
 */
(function () {
  const { MOL, UI, SHOP } = window;

  try {
    const tg = window.Telegram?.WebApp;
    if (tg) {
      tg.ready();
      tg.expand();
    }
  } catch (_) {}

  if (SHOP) SHOP.restoreTheme();

  let state = {
    char: null,
    slot: 0,
    stage: null,
    periodIndex: 0,
    eventQueue: [],
    sound: true,
    lastChoiceSnapshot: null,
    quiz: null,
  };

  function autoSave() {
    if (state.char) MOL.saveToSlot(state.slot, state.char);
  }

  function notifyAchievements(list) {
    if (!list?.length) return;
    const names = list.map((a) => a.title).join(', ');
    setTimeout(() => alert('🏆 Достижение: ' + names), 300);
  }

  function startNewGame() {
    UI.showScreen('create');
    UI.$('input-name').value = '';
    document.querySelectorAll('.seg').forEach((b) => b.classList.remove('active'));
    document.querySelector('.seg[data-gender="m"]')?.classList.add('active');
  }

  function confirmCreate() {
    const name = UI.$('input-name').value.trim() || 'Малыш';
    const gender = document.querySelector('.seg.active')?.dataset.gender || 'm';
    const country = UI.$('input-country').value;
    const income = UI.$('input-income').value;
    const saves = MOL.loadAllSaves();
    let slot = saves.findIndex((s) => !s);
    if (slot < 0) slot = 0;

    state.slot = slot;
    state.char = MOL.createCharacter({ name, gender, country, income });
    state.stage = MOL.getStage('0-3');
    state.periodIndex = 0;
    autoSave();
    notifyAchievements(SHOP.checkAchievements(state.char));
    beginPeriod();
  }

  function continueLatest() {
    const idx = MOL.findLatestSlot();
    if (idx < 0) {
      alert('Нет сохранений. Начни новую жизнь.');
      return;
    }
    loadSlot(idx);
  }

  const DEATH_CAUSE_INFO = {
    accident: { title: '💥 Непредвиденная трагедия', text: 'Эта жизнь оборвалась внезапно, независимо от принятых решений.' },
    illness: { title: '🏥 Здоровье не выдержало', text: 'Долгие проблемы со здоровьем в итоге взяли своё.' },
    bankrupt: { title: '📉 Банкротство', text: 'Финансовая яма оказалась без дна.' },
    burnout: { title: '🕯️ Точка надлома', text: 'Внутренний ресурс закончился раньше, чем получилось найти опору.' },
  };

  function loadSlot(i) {
    const ch = MOL.loadFromSlot(i);
    if (!ch) return;
    state.slot = i;
    state.char = ch;
    state.stage = MOL.getStage(ch.stageId) || MOL.getStage('0-3');
    state.periodIndex = ch.periodIndex || 0;

    if (ch.flags?.dead) {
      const info = DEATH_CAUSE_INFO[ch.flags.death_cause] || { title: 'Жизнь завершена', text: '' };
      showDeathEnding(info);
      return;
    }
    if (ch.flags?.life_complete) {
      showEnding();
      return;
    }
    if (state.periodIndex >= (state.stage?.periods?.length || 0)) {
      showStageSummary();
      return;
    }
    beginPeriod();
  }

  function beginPeriod() {
    const stage = state.stage;
    const pIdx = state.periodIndex;
    if (!stage || pIdx >= stage.periods.length) {
      showStageSummary();
      return;
    }
    // мини-игра: школьная викторина в начале 1 класса
    if (stage.id === '6-11' && pIdx === 0 && !state.char.flags.quiz_done) {
      startQuiz();
      return;
    }
    const events = MOL.getAvailableEvents(stage, pIdx, state.char);
    state.eventQueue = events.slice();
    UI.showScreen('play');
    UI.updateHeader(state.char);
    UI.updateStats(state.char);
    nextEvent();
  }

  function nextEvent() {
    if (!state.eventQueue.length) {
      state.char.ageMonths += state.stage.stepMonths;
      state.periodIndex += 1;
      state.char.periodIndex = state.periodIndex;

      // Проверка: не оборвалась ли жизнь между периодами
      const risk = MOL.evaluateLifeRisk(state.char);
      if (risk) {
        state.char.flags.dead = true;
        state.char.flags.death_cause = risk.type;
        autoSave();
        showDeathEnding(risk);
        return;
      }

      autoSave();
      notifyAchievements(SHOP.checkAchievements(state.char));
      if (state.periodIndex >= state.stage.periods.length) showStageSummary();
      else beginPeriod();
      return;
    }
    const ev = state.eventQueue.shift();
    // снимок для undo
    state.lastChoiceSnapshot = JSON.parse(JSON.stringify(state.char));
    const periodLabel = state.stage.periods[state.periodIndex]?.label || '';
    UI.renderEvent(ev, periodLabel, (choice) => onChoice(choice));
  }

  function onChoice(choice) {
    if (choice.requiresPremium && !SHOP.owns(choice.requiresPremium)) {
      if (confirm('Это премиум-ветка. Открыть магазин?')) openShop();
      return;
    }
    const before = { ...state.char.stats };
    MOL.applyEffects(state.char, choice.effects);
    const changed = {};
    for (const k of Object.keys(state.char.stats)) {
      changed[k] = state.char.stats[k] - (before[k] || 0);
    }
    UI.updateStats(state.char, changed);
    UI.updateHeader(state.char);
    autoSave();
    notifyAchievements(SHOP.checkAchievements(state.char));
    setTimeout(nextEvent, 180);
  }

  function buildBiography(char) {
    const lines = [];
    lines.push(`${char.name}, ${MOL.ageLabel(char.ageMonths)}.`);
    if (char.history?.length) {
      lines.push('');
      lines.push('Ключевые моменты:');
      char.history.slice(-12).forEach((h) => lines.push('• ' + h));
    }
    const traits = MOL.getPathTraits(char, 2).slice(0, 8);
    if (traits.length) {
      lines.push('');
      lines.push('Черты: ' + traits.map((t) => t.tag).join(', '));
    }
    return lines.join('\n');
  }

  function showStageSummary() {
    UI.showScreen('summary');
    UI.updateHeader(state.char);
    UI.updateStats(state.char);
    UI.renderSummary(
      state.char,
      state.stage?.title || 'Этап',
      () => {
        const nextId = state.stage?.nextStageId;
        if (nextId && MOL.getStage(nextId)) {
          state.stage = MOL.getStage(nextId);
          state.char.stageId = nextId;
          state.periodIndex = 0;
          state.char.periodIndex = 0;
          if (state.char.ageMonths < state.stage.ageStartMonths) {
            state.char.ageMonths = state.stage.ageStartMonths;
          }
          autoSave();
          beginPeriod();
          return;
        }
        showEnding();
      },
      () => {
        autoSave();
        goMenu();
      }
    );
  }

  function showEnding() {
    UI.showScreen('end');
    UI.$('header').classList.add('hidden');
    UI.$('stats-bar').classList.add('hidden');
    state.char.flags.life_complete = true;
    UI.$('end-title').textContent = 'Жизнь пройдена';
    const bio = buildBiography(state.char);
    UI.$('end-text').textContent = bio;
    UI.$('end-bio').classList.add('hidden');
    autoSave();
    notifyAchievements(SHOP.checkAchievements(state.char));
  }

  // Экран внезапного завершения жизни: болезнь, банкротство, срыв, несчастный случай
  function showDeathEnding(cause) {
    UI.showScreen('end');
    UI.$('header').classList.add('hidden');
    UI.$('stats-bar').classList.add('hidden');
    UI.$('end-title').textContent = cause.title;
    const intro = cause.text + '\n\n';
    const bio = buildBiography(state.char);
    UI.$('end-text').textContent = intro + bio;
    UI.$('end-bio').classList.add('hidden');
    autoSave();
  }

  function goMenu() {
    UI.showScreen('menu');
    UI.$('header').classList.add('hidden');
    UI.$('stats-bar').classList.add('hidden');
  }

  /* ---------- Shop UI ---------- */
  function openShop() {
    UI.showScreen('shop');
    const list = UI.$('shop-list');
    list.innerHTML = '';
    const meta = SHOP.loadMeta();
    Object.values(SHOP.CATALOG).forEach((item) => {
      const owned = item.type === 'consumable' ? false : !!meta.owned[item.id];
      const div = document.createElement('div');
      div.className = 'shop-item' + (owned ? ' owned' : '');
      div.innerHTML = `
        <div class="shop-item-top">
          <div>
            <strong>${item.title}</strong>
            <div class="desc">${item.desc}</div>
          </div>
          <span class="shop-price">${owned ? '✓ Есть' : item.price + ' ⭐'}</span>
        </div>`;
      if (!owned) {
        const btn = document.createElement('button');
        btn.className = 'btn btn-primary';
        btn.style.marginTop = '8px';
        btn.textContent = 'Купить';
        btn.onclick = () => {
          SHOP.purchase(
            item.id,
            () => {
              alert('Получено: ' + item.title);
              openShop();
            },
            (e) => {
              if (e !== 'отмена') alert('Не удалось: ' + e);
            }
          );
        };
        div.appendChild(btn);
      } else if (item.type === 'theme') {
        const btn = document.createElement('button');
        btn.className = 'btn btn-secondary';
        btn.style.marginTop = '8px';
        btn.textContent = 'Применить';
        btn.onclick = () => {
          SHOP.applyTheme(item.id);
          alert('Тема применена');
        };
        div.appendChild(btn);
      }
      list.appendChild(div);
    });
    const undos = document.createElement('p');
    undos.className = 'muted';
    undos.style.fontSize = '13px';
    undos.textContent = `Отмен выбора в запасе: ${meta.undos || 0} · Слотов: ${SHOP.maxSlots()}`;
    list.appendChild(undos);
  }

  function openAchievements() {
    UI.showScreen('achievements');
    const list = UI.$('ach-list');
    list.innerHTML = '';
    const meta = SHOP.loadMeta();
    SHOP.ACHIEVEMENTS.forEach((a) => {
      const unlocked = !!meta.achievements[a.id];
      const div = document.createElement('div');
      div.className = 'ach-item' + (unlocked ? '' : ' locked');
      div.innerHTML = `
        <span class="ach-icon">${unlocked ? '🏆' : '🔒'}</span>
        <div><strong>${a.title}</strong><div class="desc muted" style="font-size:12px">${a.desc}</div></div>`;
      list.appendChild(div);
    });
  }

  /* ---------- Quiz mini-game ---------- */
  const QUIZ_BANK = [
    { q: 'Сколько будет 7 × 8?', a: ['54', '56', '64', '48'], correct: 1 },
    { q: 'Столица Казахстана?', a: ['Алматы', 'Астана', 'Шымкент', 'Караганда'], correct: 1 },
    { q: '2 + 2 × 2 = ?', a: ['6', '8', '4', '10'], correct: 0 },
  ];

  function startQuiz() {
    state.quiz = {
      index: 0,
      score: 0,
      retriesLeft: SHOP.loadMeta().owned.quiz_retry ? 1 : 0,
      questions: QUIZ_BANK.slice(),
    };
    UI.showScreen('quiz');
    showQuizQuestion();
  }

  function showQuizQuestion() {
    const qz = state.quiz;
    if (qz.index >= qz.questions.length) {
      finishQuiz();
      return;
    }
    const item = qz.questions[qz.index];
    UI.$('quiz-timer').textContent = `Вопрос ${qz.index + 1}/${qz.questions.length}`;
    UI.$('quiz-q').textContent = item.q;
    UI.$('quiz-status').textContent = '';
    const box = UI.$('quiz-choices');
    box.innerHTML = '';
    item.a.forEach((text, i) => {
      const btn = document.createElement('button');
      btn.className = 'btn btn-choice';
      btn.textContent = text;
      btn.onclick = () => answerQuiz(i);
      box.appendChild(btn);
    });
  }

  function answerQuiz(i) {
    const qz = state.quiz;
    const item = qz.questions[qz.index];
    if (i === item.correct) {
      qz.score++;
      UI.$('quiz-status').textContent = 'Верно!';
    } else {
      UI.$('quiz-status').textContent = 'Неверно';
    }
    qz.index++;
    setTimeout(showQuizQuestion, 500);
  }

  function finishQuiz() {
    const qz = state.quiz;
    const good = qz.score >= 2;
    if (!good && qz.retriesLeft <= 0) {
      // предложить платную попытку
      const buy = confirm(
        `Результат: ${qz.score}/${qz.questions.length}.\nСлабовато для оценок.\nКупить ещё попытку за 25 ⭐? (тест)`
      );
      if (buy) {
        SHOP.purchase(
          'quiz_retry',
          () => {
            state.quiz = {
              index: 0,
              score: 0,
              retriesLeft: 1,
              questions: QUIZ_BANK.slice(),
            };
            showQuizQuestion();
          },
          () => afterQuiz(good)
        );
        return;
      }
    }
    afterQuiz(good);
  }

  function afterQuiz(good) {
    state.char.flags.quiz_done = true;
    if (good) {
      MOL.applyEffects(state.char, {
        stats: { intel: 4, happy: 3 },
        path: { studious: 1 },
        history: 'Хорошо написал школьную викторину',
      });
    } else {
      MOL.applyEffects(state.char, {
        stats: { intel: 1, happy: -2 },
        history: 'Викторина в школе вышла слабо',
      });
    }
    autoSave();
    // продолжить период
    const events = MOL.getAvailableEvents(state.stage, state.periodIndex, state.char);
    state.eventQueue = events.slice();
    UI.showScreen('play');
    UI.updateHeader(state.char);
    UI.updateStats(state.char);
    nextEvent();
  }

  /* ---------- Premium branch events injected at runtime ---------- */
  function injectPremiumEvents() {
    const abroad = MOL.getStage('18-25');
    if (abroad && !abroad._premiumInjected) {
      abroad.periods[0].events.push({
        id: 'premium_abroad',
        title: 'Шанс уехать',
        scene: '✈️',
        text: 'Появилась возможность стажировки за границей. (Премиум-ветка)',
        condition: (c) => SHOP.owns('branch_abroad'),
        choices: [
          {
            text: 'Уехать на год',
            effects: {
              stats: { independence: 8, social: 4, intel: 3, money: -5 },
              path: { explorer: 2 },
              flags: { lived_abroad: true },
              history: 'Жил(а) за границей в молодости',
            },
          },
          {
            text: 'Остаться',
            effects: { stats: { happy: 1 }, path: { rooted: 1 } },
          },
        ],
      });
      abroad._premiumInjected = true;
    }
    const art = MOL.getStage('25-40');
    if (art && !art._premiumInjected) {
      art.periods[0].events.push({
        id: 'premium_art',
        title: 'Творческий путь',
        scene: '🎨',
        text: 'Можно свернуть с привычной карьеры в искусство. (Премиум-ветка)',
        condition: (c) => SHOP.owns('branch_art'),
        choices: [
          {
            text: 'Уйти в творчество',
            effects: {
              stats: { happy: 8, money: -8, independence: 5 },
              path: { creative: 2 },
              flags: { artist_path: true },
              history: 'Выбрал(а) творческую карьеру',
            },
          },
          {
            text: 'Оставить как хобби',
            effects: { stats: { happy: 3 }, path: { creative: 1 } },
          },
        ],
      });
      art._premiumInjected = true;
    }
    const second = MOL.getStage('40-60');
    if (second && !second._premiumInjected) {
      second.periods[1].events.push({
        id: 'premium_second',
        title: 'Второй шанс',
        scene: '🔄',
        text: 'После 45 можно начать совсем другую профессию. (Премиум-ветка)',
        condition: (c) => SHOP.owns('branch_second'),
        choices: [
          {
            text: 'Начать с нуля',
            effects: {
              stats: { resilience: 6, independence: 5, money: -6, happy: 4 },
              path: { reinvent: 2 },
              flags: { second_career: true },
              history: 'Перезапустил(а) карьеру после 40',
            },
          },
          {
            text: 'Остаться на проторённом пути',
            effects: { stats: { money: 4 }, path: { established: 1 } },
          },
        ],
      });
      second._premiumInjected = true;
    }
  }

  injectPremiumEvents();

  /* ---------- Bindings ---------- */
  document.querySelectorAll('.seg').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.seg').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  UI.$('btn-new-game').onclick = startNewGame;
  UI.$('btn-continue').onclick = continueLatest;
  UI.$('btn-slots').onclick = () => {
    UI.showScreen('slots');
    UI.renderSlots(
      (i) => loadSlot(i),
      (i) => {
        MOL.deleteSlot(i);
        UI.renderSlots((x) => loadSlot(x), (x) => { MOL.deleteSlot(x); openSlotsRefresh(); }, () => UI.showScreen('menu'));
      },
      () => UI.showScreen('menu')
    );
  };
  function openSlotsRefresh() {
    UI.renderSlots(
      (i) => loadSlot(i),
      (i) => {
        MOL.deleteSlot(i);
        openSlotsRefresh();
      },
      () => UI.showScreen('menu')
    );
  }

  UI.$('btn-shop').onclick = openShop;
  UI.$('btn-shop-back').onclick = () => UI.showScreen('menu');
  UI.$('btn-achievements').onclick = openAchievements;
  UI.$('btn-ach-back').onclick = () => UI.showScreen('menu');
  UI.$('btn-start-life').onclick = confirmCreate;
  UI.$('btn-back-menu').onclick = () => UI.showScreen('menu');
  UI.$('btn-to-menu').onclick = goMenu;
  UI.$('btn-menu').onclick = () => {
    if (confirm('Выйти в меню? Прогресс сохранён.')) {
      autoSave();
      goMenu();
    }
  };
  UI.$('btn-sound').onclick = () => {
    state.sound = !state.sound;
    UI.$('btn-sound').textContent = state.sound ? '🔊' : '🔇';
  };

  UI.$('btn-bio-pretty').onclick = () => {
    if (!state.char) return;
    if (SHOP.owns('bio_card')) {
      const el = UI.$('end-bio');
      el.textContent = '✦ ─── Моя обычная жизнь ─── ✦\n\n' + buildBiography(state.char) + '\n\n✦ ───────────── ✦';
      el.classList.remove('hidden');
      UI.$('end-text').classList.add('hidden');
    } else {
      SHOP.purchase(
        'bio_card',
        () => {
          UI.$('btn-bio-pretty').click();
        },
        () => {}
      );
    }
  };

  UI.$('btn-share-bio').onclick = () => {
    const text = buildBiography(state.char || { name: '?', ageMonths: 0, history: [], path: {}, stats: {} });
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(() => alert('Биография скопирована'));
    } else {
      prompt('Скопируй текст:', text);
    }
  };

  UI.showScreen('menu');
})();
